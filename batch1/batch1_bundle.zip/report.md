# Batch 1 data job — report

Run date: 2026-10-02 (UTC). **Result: no external data collected.** Every required host was refused by this execution environment's egress proxy (`Tunnel connection failed: 403 Forbidden`, a policy denial, not a service outage). Per the job rules, no values were guessed or substituted; every output file is present with its schema, and rows are marked `unknown` / `none` / `not_run`.

To re-run: allow these hosts in the environment's network settings (https://code.claude.com/docs/en/cloud-environments#network-access): `feature.geographic.texas.gov`, `router.project-osrm.org`, `waterservices.usgs.gov`, plus the listing sites (`www.landwatch.com`, `www.land.com`, `www.landsoftexas.com`, `www.har.com`, broker domains).

## 1. Parcel coverage

| county | parcel_count | data_date | status |
|---|---|---|---|
| Bandera | — | — | unknown (not queried) |
| Blanco | — | — | unknown (not queried) |
| Edwards | — | — | unknown (not queried) |
| Gillespie | — | — | unknown (not queried) |
| Kendall | — | — | unknown (not queried) |
| Kerr | — | — | unknown (not queried) |
| Kimble | — | — | unknown (not queried) |
| Mason | — | — | unknown (not queried) |
| Medina | — | — | unknown (not queried) |
| Menard | — | — | unknown (not queried) |
| Real | — | — | unknown (not queried) |
| Sutton | — | — | unknown (not queried) |
| Uvalde | — | — | unknown (not queried) |

## 2. Parcel matches

| listing | listing acres | confidence | parcel acres | situs |
|---|---|---|---|---|
| rce (Rancho Cinco Estrella) | 130.02 | none | — | — |
| bass (Bass & Hays Ranch) | 380 | none | — | — |
| fran (Frances Creek Ranch) | 371.33 | none | — | — |
| exh (Exotic Hills Ranch) | 309 | none | — | — |
| cbe (Canyon Breeze Estate) | 214 | none | — | — |
| bull (Bullhead Creek Ranch) | 347 | none | — | — |
| cve (Camp Verde Escape) | 65 | none | — | — |
| wrr (West River Ranch) | 82.74 | none | — | — |
| mof (Moffett Ridge Ranch) | 62.92 | none | — | — |
| boot (Bootlegger Estate) | 50 | none | — | — |
| chs (Cherry Springs Ranch) | 205.7 | none | — | — |
| vmr (Vista Madrone Ranch) | 100 | none | — | — |
| rea (Reavis Ranch) | 119.5 | none | — | — |
| mck (1600 Mickle Creek Rd) | 176 | none | — | — |
| mcr (Mickle Creek Ranch) | 246 | none | — | — |
| h16 (18954 Hwy 16 N) | 172 | none | — | — |
| vcr (Verde Creek Ranch (China St)) | 98.57 | none | — | — |
| bwr (Blue Wildebeest Ranch) | 47 | none | — | — |
| blf (Bluff Creek Ranch) | 44.8 | none | — | — |
| lat (Latham 1222 Ranch) | 158.8 | none | — | — |
| bkt (Bucket List Ranch) | 525 | none | — | — |
| jac (JA Canyon) | 315 | none | — | — |
| hlr (High Lonesome Ranch) | 439.88 | none | — | — |
| hh (The H & H Ranch) | 348 | none | — | — |
| wpt (Westpoint Ranch) | 435.54 | none | — | — |
| mni (M & I Ranch) | 622.22 | none | — | — |
| dd (Double D Ranch (KC 24)) | 655.6 | none | — | — |
| jhr (Junction Hunting Ranch) | 289 | none | — | — |
| k189 (189 ac Kimble County (KC 3721)) | 189 | none | — | — |
| bda (Bois D' Arc Ranch) | 140 | none | — | — |
| dun (Duncan River Ranch) | 77 | none | — | — |
| blau (348 Blau Lane) | 247 | none | — | — |
| oak (Oak Ridge Ranch) | 138.61 | none | — | — |
| fmm (Flying MMM on the Llano) | 100 | none | — | — |
| pcr (Prairie Canyon Ranch) | 108.98 | none | — | — |
| ond (Ondine Ranch) | 200 | none | — | — |
| mtt (Mt. Tremont Ranch) | 200 | none | — | — |
| lvc (Lake View Canyon Ranch) | 248 | none | — | — |
| boh (Bohnert River Ranch) | 85 | none | — | — |
| pal (Palmetto Creek Ranch) | 72 | none | — | — |
| cwc (Cottonwood Creek Ranch) | 140 | none | — | — |
| vvr (Valley View Ranch) | 101.21 | none | — | — |
| cir (Circle A Ranch) | 140.28 | none | — | — |
| brr (Barker-Rogers Ranch) | 117 | none | — | — |
| ado (Adobe Springs Ranch) | 77.59 | none | — | — |

## 3. Drive times (OSRM)

| metric | value |
|---|---|
| min / median / max minutes | n/a — no route returned |
| listing routes attempted | 1 of 45 (step stopped after first failure, per instructions) |
| grid table calls | 0 of 5 (400 cell centres written to drive_grid.csv, minutes blank) |
| failures | 45 listings + 400 grid points without a duration |

## 4. Stream gauges (USGS NWIS)

Site service call failed, so no names were verified and no daily values were downloaded (0 of ~20). The bbox search for additional gauges was not run. Names below are the job's input labels, not USGS-verified.

| site_no | input name | days | pct no-flow | yrs w/ no-flow | longest streak | median cfs | latest | pctile |
|---|---|---|---|---|---|---|---|---|
| 08195000 | Frio River at Concan | — | — | — | — | — | — | — |
| 08198000 | Sabinal River near Sabinal | — | — | — | — | — | — | — |
| 08190000 | Nueces River at Laguna | — | — | — | — | — | — | — |
| 08190500 | West Nueces River near Brackettville | — | — | — | — | — | — | — |
| 08165500 | Guadalupe River at Hunt | — | — | — | — | — | — | — |
| 08167000 | Guadalupe River at Comfort | — | — | — | — | — | — | — |
| 08150000 | Llano River near Junction | — | — | — | — | — | — | — |
| 08151500 | Llano River at Llano | — | — | — | — | — | — | — |
| 08178880 | Medina River at Bandera | — | — | — | — | — | — | — |
| 08144500 | San Saba River at Menard | — | — | — | — | — | — | — |
| 08153500 | Pedernales River near Johnson City | — | — | — | — | — | — | — |
| 08171000 | Blanco River at Wimberley | — | — | — | — | — | — | — |

listing_gauges.csv: all 45 listings `not_run` (gauge coordinates needed for distance were never retrieved).

## 5. Market listings

0 rows. All four aggregator probes (LandWatch, Land.com, Lands of Texas, HAR) were refused; broker domains from the input list were refused earlier in the session (bowndsranches.com, texasranchesforsale.com). market_listings.csv contains the header only.

## Failed / skipped

| step | url | time (UTC) | error |
|---|---|---|---|
| 1 parcel layer description | `https://feature.geographic.texas.gov/arcgis/rest/services/Parcels/stratmap_land_parcels_48_most_recent/MapServer/0?f=pjson` | 2026-10-02T21:17:59Z | `ProxyError: HTTPSConnectionPool(host='feature.geographic.texas.gov', port=443): Max retries exceeded with url: /arcgis/rest/services/Parcels/stratmap_land_parcels_48_most_recent/MapServer/0?f=pjson (Caused by ProxyError('Unable to connect to proxy', OSError('Tunnel connection failed: 403 Forbidden')))` |
| 3 OSRM route (first call; step stopped) | `https://router.project-osrm.org/route/v1/driving/-95.63,29.784;-99.6262,29.7402?overview=false` | 2026-10-02T21:18:00Z | `ProxyError: HTTPSConnectionPool(host='router.project-osrm.org', port=443): Max retries exceeded with url: /route/v1/driving/-95.63,29.784;-99.6262,29.7402?overview=false (Caused by ProxyError('Unable to connect to proxy', OSError('Tunnel connection failed: 403 Forbidden')))` |
| 4 USGS site service | `https://waterservices.usgs.gov/nwis/site/?format=rdb&sites=08195000,08198000,08190000,08190500,08165500,08167000,08150000,08151500,08178880,08144500,08153500,08171000&siteOutput=expanded` | 2026-10-02T21:18:01Z | `ProxyError: HTTPSConnectionPool(host='waterservices.usgs.gov', port=443): Max retries exceeded with url: /nwis/site/?format=rdb&sites=08195000,08198000,08190000,08190500,08165500,08167000,08150000,08151500,08178880,08144500,08153500,08171000&siteOutput=expanded (Caused by ProxyError('Unable to connect to proxy', OSError('Tunnel connection failed: 403 Forbidden')))` |
| 5 market source | `https://www.landwatch.com/` | 2026-10-02T21:18:02Z | `ProxyError: HTTPSConnectionPool(host='www.landwatch.com', port=443): Max retries exceeded with url: / (Caused by ProxyError('Unable to connect to proxy', OSError('Tunnel connection failed: 403 Forbidden')))` |
| 5 market source | `https://www.land.com/` | 2026-10-02T21:18:04Z | `ProxyError: HTTPSConnectionPool(host='www.land.com', port=443): Max retries exceeded with url: / (Caused by ProxyError('Unable to connect to proxy', OSError('Tunnel connection failed: 403 Forbidden')))` |
| 5 market source | `https://www.landsoftexas.com/` | 2026-10-02T21:18:05Z | `ProxyError: HTTPSConnectionPool(host='www.landsoftexas.com', port=443): Max retries exceeded with url: / (Caused by ProxyError('Unable to connect to proxy', OSError('Tunnel connection failed: 403 Forbidden')))` |
| 5 market source | `https://www.har.com/` | 2026-10-02T21:18:06Z | `ProxyError: HTTPSConnectionPool(host='www.har.com', port=443): Max retries exceeded with url: / (Caused by ProxyError('Unable to connect to proxy', OSError('Tunnel connection failed: 403 Forbidden')))` |

Skipped as a consequence (no request sent):

- Step 1: 13 county count queries (layer description unreachable).
- Step 2: all parcel envelope queries (≤3 × 45) and broker-page fetches (≤45).
- Step 3: remaining 44 route calls and all 5 table calls (instruction: stop the step if OSRM is unavailable).
- Step 4: bbox gauge search and all daily-value downloads; all statistics; listing→gauge mapping.
- Step 5: all listing collection.
- A WebFetch attempt on the TxGIO layer description was also refused (`EGRESS_BLOCKED`). No other data source was substituted.
