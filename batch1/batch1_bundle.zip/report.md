# Batch 1 data job: report

Run 2026-10-02 (UTC). Polite client: one request at a time, ≥1 s per host, UA `ranch-search-job/1.0`. Every request is logged in `calls.jsonl` (in the repo, not the bundle).

## Summary

| Step | Result |
|---|---|
| 1 Parcel coverage | **Failed.** The layer description loads, but every `/query` call (count, attribute, envelope, objectIds; GET and POST) returns ArcGIS error 400 *Requested operation is not supported by this service.* No FeatureServer endpoint exists. |
| 2 Parcel match | **Not run** (depends on Step 1). 45 listings marked `none`; parcels.geojson is empty. |
| 3 Drive times | **Done.** 45/45 routes and 400/400 grid points (45 route + 5 table calls). |
| 4 Gauges | **Mostly done.** 18 of 20 gauges have statistics. 2 failed repeatedly with USGS 503 / truncated responses. |
| 5 Market listings | **Failed.** 0 rows. The aggregators return 403 *Access Denied* (bot protection), and every broker domain is still blocked by this environment's egress policy. |

## 1. Parcel coverage

Layer fields (from `?f=pjson`): objectid, prop_id, geo_id, owner_name, name_care, legal_area, gis_area, legal_desc, land_value, imp_value, mkt_value, situs_addr, situs_num, situs_stre, situs_st_1, situs_st_2, situs_city, situs_stat, situs_zip, mail_addr, mail_line1, mail_line2, mail_city, mail_stat, mail_zip, source, date_acq (date), fips, county, tax_year, year_built, shape, st_area(shape), st_perimeter(shape), lgl_area_unit, gis_area_unit, stat_land_use, loc_land_use. Acreage field: `gis_area` (unit in `gis_area_unit`). maxRecordCount 2000. The layer advertises `Query,Map`, but the server refuses queries.

| county | parcel_count | data_date | status |
|---|---|---|---|
| Bandera | — | — | unknown (query refused) |
| Blanco | — | — | unknown (query refused) |
| Edwards | — | — | unknown (query refused) |
| Gillespie | — | — | unknown (query refused) |
| Kendall | — | — | unknown (query refused) |
| Kerr | — | — | unknown (query refused) |
| Kimble | — | — | unknown (query refused) |
| Mason | — | — | unknown (query refused) |
| Medina | — | — | unknown (query refused) |
| Menard | — | — | unknown (query refused) |
| Real | — | — | unknown (query refused) |
| Sutton | — | — | unknown (query refused) |
| Uvalde | — | — | unknown (query refused) |

## 2. Parcel matches

| listing | listing acres | confidence | parcel acres | situs |
|---|---|---|---|---|
| rce: Rancho Cinco Estrella | 130.02 | none | — | — |
| bass: Bass & Hays Ranch | 380 | none | — | — |
| fran: Frances Creek Ranch | 371.33 | none | — | — |
| exh: Exotic Hills Ranch | 309 | none | — | — |
| cbe: Canyon Breeze Estate | 214 | none | — | — |
| bull: Bullhead Creek Ranch | 347 | none | — | — |
| cve: Camp Verde Escape | 65 | none | — | — |
| wrr: West River Ranch | 82.74 | none | — | — |
| mof: Moffett Ridge Ranch | 62.92 | none | — | — |
| boot: Bootlegger Estate | 50 | none | — | — |
| chs: Cherry Springs Ranch | 205.7 | none | — | — |
| vmr: Vista Madrone Ranch | 100 | none | — | — |
| rea: Reavis Ranch | 119.5 | none | — | — |
| mck: 1600 Mickle Creek Rd | 176 | none | — | — |
| mcr: Mickle Creek Ranch | 246 | none | — | — |
| h16: 18954 Hwy 16 N | 172 | none | — | — |
| vcr: Verde Creek Ranch (China St) | 98.57 | none | — | — |
| bwr: Blue Wildebeest Ranch | 47 | none | — | — |
| blf: Bluff Creek Ranch | 44.8 | none | — | — |
| lat: Latham 1222 Ranch | 158.8 | none | — | — |
| bkt: Bucket List Ranch | 525 | none | — | — |
| jac: JA Canyon | 315 | none | — | — |
| hlr: High Lonesome Ranch | 439.88 | none | — | — |
| hh: The H & H Ranch | 348 | none | — | — |
| wpt: Westpoint Ranch | 435.54 | none | — | — |
| mni: M & I Ranch | 622.22 | none | — | — |
| dd: Double D Ranch (KC 24) | 655.6 | none | — | — |
| jhr: Junction Hunting Ranch | 289 | none | — | — |
| k189: 189 ac Kimble County (KC 3721) | 189 | none | — | — |
| bda: Bois D' Arc Ranch | 140 | none | — | — |
| dun: Duncan River Ranch | 77 | none | — | — |
| blau: 348 Blau Lane | 247 | none | — | — |
| oak: Oak Ridge Ranch | 138.61 | none | — | — |
| fmm: Flying MMM on the Llano | 100 | none | — | — |
| pcr: Prairie Canyon Ranch | 108.98 | none | — | — |
| ond: Ondine Ranch | 200 | none | — | — |
| mtt: Mt. Tremont Ranch | 200 | none | — | — |
| lvc: Lake View Canyon Ranch | 248 | none | — | — |
| boh: Bohnert River Ranch | 85 | none | — | — |
| pal: Palmetto Creek Ranch | 72 | none | — | — |
| cwc: Cottonwood Creek Ranch | 140 | none | — | — |
| vvr: Valley View Ranch | 101.21 | none | — | — |
| cir: Circle A Ranch | 140.28 | none | — | — |
| brr: Barker-Rogers Ranch | 117 | none | — | — |
| ado: Adobe Springs Ranch | 77.59 | none | — | — |

Broker-page fetches (≤1 per listing) were not attempted. They are only useful for picking between parcel candidates, and every broker domain is blocked here anyway.

## 3. Drive times (OSRM demo server, car profile)

| metric | listings (n=45) | grid (n=400) |
|---|---|---|
| min minutes | 212.4 (vvr) | 137.4 |
| median minutes | 292.4 | 296.8 |
| max minutes | 449.1 (hh) | 490.1 |
| failures | 0 | 0 |

Large snap distances (>1 km from pin to nearest routable road): lat 1070.1 m, jhr 2436.3 m, pal 1371.1 m. Grid points snapping >5 km: 1. Caveat: OSRM demo times are free-flow (no traffic) and usually optimistic against real Houston departures.

## 4. Stream gauges (USGS NWIS daily values, 00060, 2006-10-01 to 2026-10-02)

No-flow = daily mean ≤ 0.1 cfs. Water years run Oct–Sep. latest_pctile = rank of the latest value among all earlier values in the same ISO week (mid-rank, 0–100). Every latest value carries qualifier `P` (provisional). `extra` = gauges from the bbox search (134 active sites) chosen because they are the nearest gauge to the most listings, capped at 8.

| site | name | sel | days | % no-flow | WYs w/ no-flow | longest dry (d) | median cfs | latest | cfs | pctile |
|---|---|---|---|---|---|---|---|---|---|---|
| 08144500 | San Saba Rv at Menard, TX | named | failed | | | | | | | |
| 08150000 | Llano Rv nr Junction, TX | named | 7306 | 0.0 | 0/21 | 0 | 76.9 | 2026-10-01 | 10700.0 | 100.0 |
| 08151500 | Llano Rv at Llano, TX | named | 7293 | 0.32 | 3/21 | 19 | 94.5 | 2026-10-01 | 2440.0 | 100.0 |
| 08153500 | Pedernales Rv nr Johnson City, TX | named | failed | | | | | | | |
| 08165500 | Guadalupe Rv at Hunt, TX | named | 7304 | 0.0 | 0/21 | 0 | 25.4 | 2026-10-01 | 54.7 | 95.1 |
| 08167000 | Guadalupe Rv at Comfort, TX | named | 7306 | 1.36 | 4/21 | 80 | 56.3 | 2026-10-01 | 139.0 | 90.2 |
| 08171000 | Blanco Rv at Wimberley, TX | named | 7306 | 0.0 | 0/21 | 0 | 25.9 | 2026-10-01 | 9.37 | 24.5 |
| 08178880 | Medina Rv at Bandera, TX | named | 7306 | 7.27 | 8/21 | 164 | 16.4 | 2026-10-01 | 34.7 | 77.6 |
| 08190000 | Nueces Rv at Laguna, TX | named | 7306 | 0.0 | 0/21 | 0 | 53.85 | 2026-10-01 | 341.0 | 85.3 |
| 08190500 | W Nueces Rv nr Brackettville, TX | named | 7300 | 64.21 | 19/21 | 414 | 0.03 | 2026-10-01 | 2.64 | 79.7 |
| 08195000 | Frio Rv at Concan, TX | named | 7306 | 2.27 | 4/21 | 46 | 30.5 | 2026-10-01 | 83.4 | 85.3 |
| 08198000 | Sabinal Rv nr Sabinal, TX | named | 7306 | 27.37 | 13/21 | 457 | 2.46 | 2026-10-01 | 26.9 | 84.6 |
| 0818999010 | Nueces Rv nr Barksdale, TX | extra | 6366 | 0.0 | 0/18 | 0 | 28.1 | 2026-09-30 | 53.4 | 88.6 |
| 0817887350 | Medina Rv at Patterson Rd at Medina, TX | extra | 5439 | 0.02 | 1/16 | 1 | 11.3 | 2026-10-01 | 20.7 | 78.2 |
| 08166250 | Guadalupe Rv nr Center Point, TX | extra | 6469 | 0.0 | 0/20 | 0 | 41.6 | 2026-10-01 | 157.0 | 100.0 |
| 08197936 | Sabinal Rv bl Mill Ck nr Vanderpool, TX | extra | 4681 | 2.88 | 4/15 | 31 | 0.97 | 2026-10-01 | 27.5 | 92.6 |
| 08166140 | Guadalupe Rv abv Bear Ck at Kerrville, TX | extra | 7190 | 0.0 | 0/21 | 0 | 44.3 | 2026-10-01 | 194.0 | 100.0 |
| 08150700 | Llano Rv nr Mason, TX | extra | 7306 | 0.01 | 1/21 | 1 | 91.4 | 2026-10-01 | 10400.0 | 100.0 |
| 08449100 | Dolan Ck abv Devils River nr Comstock, TX | extra | 5344 | 0.0 | 0/15 | 0 | 12.9 | 2026-09-30 | 1.8 | 2.0 |
| 08148500 | N Llano Rv nr Junction, TX | extra | 7306 | 9.91 | 10/21 | 175 | 12.6 | 2026-10-01 | 1070.0 | 100.0 |

The Llano gauges (Junction 10,700 cfs, Mason 10,400 cfs, N Llano 1,070 cfs) and the Guadalupe gauges at Kerrville and Center Point were at their 100th weekly percentile on 2026-10-01. That points to a high-flow event, and these are provisional values.

Listing → gauge: 2 same_river (fmm → Llano nr Mason, boh → Guadalupe at Comfort), 43 nearest. dun (Menard) should map to San Saba at Menard, but that download failed, so the nearest gauge (N Llano nr Junction, 44 km) was used and flagged. See listing_gauges.csv.

## 5. Market listings

0 rows (header only). Nothing was guessed or filled from memory.

## Failed / skipped (with error text)

| step | target | error |
|---|---|---|
| 1 count ×26 (13 counties, mixed and upper case) | `.../MapServer/0/query?where=county='X'&returnCountOnly=true` | ArcGIS JSON error 400 (-2147220222): "Requested operation is not supported by this service." / "The requested capability is not supported." |
| 1 date stats | `/query` outStatistics grouped by county | ArcGIS JSON error 400 (-2147220222): "Requested operation is not supported by this service." / "The requested capability is not supported." |
| 1 probes ×5 | `where=1=1` count; attribute query; 4326 envelope query; objectIds=1; POST count | ArcGIS JSON error 400 (-2147220222): "Requested operation is not supported by this service." / "The requested capability is not supported." |
| 1 FeatureServer probe | `.../FeatureServer/0/query` | `Server object extension 'featureserver' not found.` |
| 2 all | parcel envelope queries, broker pages | skipped: depends on Step 1 |
| 4 site service (1st) | site?sites=12 named | HTTP 503 `Service unavailable, please try again later`; OK on retry |
| 4 bbox search | site?bBox=… | HTTP 503; then ReadTimeout (60 s); OK on 3rd try with 180 s timeout |
| 4 dv 08144500 | daily values | ContentDecodingError: ('Received response with content-encoding: gzip, but failed to decode it.', error('Error |
| 4 dv 08153500 | daily values | ContentDecodingError: ('Received response with content-encoding: gzip, but failed to decode it.', error('Error |
| 4 dv 08190000 | daily values | HTTP 503: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-st |
| 4 dv 08195000 | daily values | HTTP 503: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-st |
| 4 dv 08166250 | daily values | ContentDecodingError: ('Received response with content-encoding: gzip, but failed to decode it.', error('Error |
| 4 dv 08148500 | daily values | ContentDecodingError: ('Received response with content-encoding: gzip, but failed to decode it.', error('Error |
| 4 dv 08144500 | daily values | HTTP 503: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-st |
| 4 dv 08153500 | daily values | HTTP 503: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-st |
| 4 dv 08190000 | daily values | HTTP 503: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-st |
| 4 dv 08144500 | daily values | ChunkedEncodingError: Response ended prematurely |
| 4 dv 08153500 | daily values | HTTP 503: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-st |
| 4 final | 08144500 San Saba at Menard, 08153500 Pedernales nr Johnson City | still failing after 3 attempts each; no statistics |
| 5 | www.landwatch.com | HTTP 403 Access Denied (site bot protection) |
| 5 | www.land.com | HTTP 403 Access Denied (site bot protection) |
| 5 | www.landsoftexas.com | HTTP 403 Access Denied (site bot protection) |
| 5 | www.har.com | HTTP 403 Access Denied (site bot protection) |
| 5 | www.texaslandmen.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | dullnigranches.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.texasranchesforsale.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.bowndsranches.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.texaslandandranch.net | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | westandswoperanches.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.meekranchsales.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | republicranches.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.whitetailproperties.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | robersonlandco.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.ahernranches.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.mockranches.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.hoodrealestateinc.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | westernhillcountryrealty.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | simpsonranches.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.bierschwalelandco.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | frazierranchsales.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | andersranchrealty.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.therenorealtygroup.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | jacobylandco.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | texasranchsalesllc.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | mikeandcodystexasranchsales.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | homeslandcountrypropertyforsale.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.alamocityrealty.com | egress policy: Tunnel connection failed: 403 Forbidden |
| 5 | www.stephenlongproperties.com | egress policy: Tunnel connection failed: 403 Forbidden |

**Budget notes.** Parcels: 0 envelope queries, but 33 failed count/probe calls. OSRM: 45 route + 5 table (exact). USGS: 4 site calls (budget 1; 2 needed by design plus retries after 503/timeout) and 29 daily-value calls (budget ~20; 20 sites + 9 retries after 503/truncated responses). Step 5: 1 GET per host.

**To fill the gaps:** (1) The TxGIO parcel service needs to work again, or the job needs an approved alternative parcel source (none was substituted). (2) Allow the broker domains in the environment network policy. (3) The aggregators block scripted clients regardless of network settings, so Step 5 would need their permission or a data feed.
